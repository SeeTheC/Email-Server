Mabola: Blue Skin for Roundcube Webmail
==================================

Refer to https://github.com/EstudioNexos/mabola

Please post issues at Mabola main repo.
