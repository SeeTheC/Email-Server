jquery_mobile
=============

Presentation
------------

Plugin for adding the complete jquery_mobile (http://jquerymobile.com/) library to Roundcube. Like the jqueryui plugin, this allows other plugins to use jquery_mobile without habing to load their own version.


Version
-------

jquery mobile 1.4.5


Author
------

PNE Annuaire et Messagerie/MEDDE


Installation
------------

Rename the folder to "jquery_mobile" and add it to your Roundcube instance/plugins directory. You MUST NOT add it in the Roundcube configuration file, the plugin is automatically loaded by the mobile plugin.
